# apollo-graphql-lambda
Example apollo graphql deployment to AWS

## Background
Following this guide
https://www.apollographql.com/docs/apollo-server/deployment/lambda/#managing-the-resulting-services
